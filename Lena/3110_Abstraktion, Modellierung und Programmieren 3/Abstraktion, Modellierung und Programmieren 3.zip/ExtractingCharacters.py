#extracting character from string
string = "Python"

#extracting second and third character
print(string[1:3])