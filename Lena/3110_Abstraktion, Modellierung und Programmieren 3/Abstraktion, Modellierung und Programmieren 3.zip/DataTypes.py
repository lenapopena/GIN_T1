wert1 = 5
text1 =f"Der Datentyp lautet {type(wert1)} und die Schreibform ist {wert1}."
print(text1)

wert2 = "A"
text2 = f"Der Datentyp lautet {type(wert2)} und die Schreibform ist {wert2}."
print(text2)

wert3 = 1.1
text3 = f"Der Datentyp lautet {type(wert3)} und die Schreibform ist {wert3}."
print(text3)

wert4 = True
text4 = f"Der Datentyp lautet {type(wert4)} und die Schreibform ist {wert4}."
print(text4)

wert5 = "Python ist spannend!"
text5 = f"Der Datentyp lautet {type(wert5)} und die Schreibform ist {wert5}."
print(text5)

wert6 = 5.3
text6 = f"Der Datentyp lautet {type(wert6)} und die Schreibform ist {wert6}."
print(text6)