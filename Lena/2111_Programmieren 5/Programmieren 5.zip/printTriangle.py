
def zeichne_dreieck(hoehe):
    
    for i in range(1, hoehe + 1):  # Schleife von 1 bis zur Höhe
        print('#' * i)  # Gibt i-mal # aus


zeichne_dreieck(4)
