def wiederhole_nachricht(nachricht, anzahl):
    for _ in range(anzahl):
        print(nachricht)

wiederhole_nachricht("Python macht Spaß!", 3)