#Question 1
print("What is the capital of Germany?\n")
print("(A) Berlin")
print("(B) Hamburg")
print("(C) Köln")
print("(D) München")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "A":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 2
print("What is the capital of Austria?\n")
print("(A) Linz")
print("(B) Bregenz")
print("(C) Wien")
print("(D) Klagenfurt")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "C":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 3
print("What is the capital of Spain?\n")
print("(A) Bilbao")
print("(B) Madrid")
print("(C) Valencia")
print("(D) Barcelona")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "B":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 4
print("What is the capital of the Netherlands?\n")
print("(A) Maastricht")
print("(B) Rotterdam")
print("(C) Den Haag")
print("(D) Amsterdam")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "D":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 5
print("What is the capital of the Czech Republic?\n")
print("(A) Prag")
print("(B) Krumau")
print("(C) Budweis")
print("(D) Brenn")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "A":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 6
print("What is the capital of Italy?\n")
print("(A) Vatican")
print("(B) Rome")
print("(C) Brixen")
print("(D) Palermo")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "A":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 7
print("What is the capital of Ireland?\n")
print("(A) Kirk")
print("(B) Galway")
print("(C) Dublin")
print("(D) Kilkenny")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "C":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")

#Question 8
print("What is the capital of France?\n")
print("(A) Marseille")
print("(B) Bordeaux")
print("(C) Lyon")
print("(D) Paris")
print("---------------------------------")

answer = input("Your answer: ")

if answer.upper() == "D":
    print("Answer is correct!")
else:
    print("Answer is incorrect!")
print("---------------------------------\n")